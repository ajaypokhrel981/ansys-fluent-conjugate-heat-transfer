import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path
from scipy.interpolate import griddata

# ============================================================
# EDIT ONLY THESE 3 LINES FOR EACH CASE
# ============================================================
Re_label = "2000"
FLUID_FILE = "fluid_Re2000.csv"   # OR "fluid_Re200.csv.csv"
SOLID_FILE = "solid_Re2000.csv"   # OR "solid_Re200.csv.csv"
# ============================================================

# -------------------- Problem constants ---------------------
H = 0.1
Te = 300.0
q_flux = 10.0
kf = 0.0242
q_flux_H_over_kf = q_flux * H / kf  # 41.3223

# Geometry (Case 5)
Le_star = 2.0
w_star  = 0.25
h_star  = 0.25

# Plot window (paper-like)
XMIN, XMAX = 1.7, 5.0
YMIN, YMAX = 0.0, 1.0

# Grid for FLUID contouring
NX, NY = 900, 360   # <-- increased NY so the 0.01 streamline shows clearly

# Streamline levels (paper-like)
levels_main = [0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9]

# IMPORTANT: small streamline levels (include 0.01 explicitly like the paper)
levels_small_candidates = [
    -0.016, -0.010, -0.006, -0.001,
     0.001,  0.003,  0.006,  0.010, 0.016
]

# Isotherm levels (paper-like for FLUID)
theta_levels_requested = [0.001, 0.004, 0.007, 0.010, 0.016, 0.022, 0.026, 0.030, 0.034, 0.038, 0.042]

# Output
DPI = 600
SAVE_PREFIX = f"Re{Re_label}_paperstyle"

# -------------------- Helpers -------------------------------
BASE = Path(__file__).resolve().parent

def resolve_file(name: str) -> Path:
    """Resolve relative to script folder; auto-fix .csv.csv mistakes."""
    p = Path(name)
    if not p.is_absolute():
        p = BASE / p

    if p.exists():
        return p

    if str(p).endswith(".csv") and Path(str(p) + ".csv").exists():
        return Path(str(p) + ".csv")

    if str(p).endswith(".csv.csv"):
        p2 = Path(str(p).replace(".csv.csv", ".csv"))
        if p2.exists():
            return p2

    raise FileNotFoundError(f"File not found: {p}")

def norm_col(s: str) -> str:
    return s.strip().lower().replace(" ", "-").replace("_", "-")

def clean_headers(df):
    df.columns = [norm_col(c) for c in df.columns]
    return df

def get_col(df, *cands):
    cols = df.columns
    for c in cands:
        c = norm_col(c)
        if c in cols:
            return df[c].to_numpy(copy=True)
    raise KeyError(f"Missing columns {cands}. Available: {cols.tolist()}")

def interp_to_grid(x, y, val, Xi, Yi):
    """Linear interpolation + nearest fill to remove NaN holes."""
    Vi_lin = griddata((x, y), val, (Xi, Yi), method="linear")
    Vi_nn  = griddata((x, y), val, (Xi, Yi), method="nearest")
    return np.where(np.isnan(Vi_lin), Vi_nn, Vi_lin)

def filter_levels(levels, vmin, vmax):
    return [lv for lv in levels if (lv >= vmin and lv <= vmax)]


# ============================================================
# LOAD FLUID
# ============================================================
fluid_path = resolve_file(FLUID_FILE)
solid_path = resolve_file(SOLID_FILE)

df_f = pd.read_csv(fluid_path, skipinitialspace=True)
df_f = clean_headers(df_f)
print("Fluid columns:", df_f.columns.tolist())

x = get_col(df_f, "x-coordinate", "x")
y = get_col(df_f, "y-coordinate", "y")
T = get_col(df_f, "temperature", "static-temperature")
psi = get_col(df_f, "stream-function", "streamfunction")

y = np.where(np.abs(y) < 1e-12, 0.0, y)

x_star = x / H
y_star = y / H
theta_f = (T - Te) / q_flux_H_over_kf

# Streamfunction normalization: psi* = 0 at bottom wall, 1 at top wall at inlet
inlet_mask = x_star < 0.05
psi_bottom = psi[inlet_mask][np.argmin(y_star[inlet_mask])]
psi_top    = psi[inlet_mask][np.argmax(y_star[inlet_mask])]
psi_star = (psi - psi_bottom) / (psi_top - psi_bottom)

# ============================================================
# GRID + INTERPOLATION (FLUID)
# ============================================================
xi = np.linspace(XMIN, XMAX, NX)
yi = np.linspace(YMIN, YMAX, NY)
Xi, Yi = np.meshgrid(xi, yi)

mask = (x_star >= XMIN-0.2) & (x_star <= XMAX+0.2) & (y_star >= YMIN) & (y_star <= YMAX)

Psi_i   = interp_to_grid(x_star[mask], y_star[mask], psi_star[mask], Xi, Yi)
Theta_i = interp_to_grid(x_star[mask], y_star[mask], theta_f[mask],   Xi, Yi)

psi_min, psi_max = float(np.nanmin(Psi_i)), float(np.nanmax(Psi_i))
th_min, th_max   = float(np.nanmin(Theta_i)), float(np.nanmax(Theta_i))

# ---- Mask obstacle region so FLUID contours do NOT appear inside solid ----
inside_obs = (Xi >= Le_star) & (Xi <= Le_star + w_star) & (Yi >= 0.0) & (Yi <= h_star)
Psi_plot = Psi_i.copy()
Theta_plot = Theta_i.copy()
Psi_plot[inside_obs] = np.nan
Theta_plot[inside_obs] = np.nan

print("Psi_i window min/max   =", psi_min, psi_max)

# ============================================================
# LOAD SOLID (OBSTACLE) + BUILD SMOOTH SOLID GRID  (UNCHANGED)
# ============================================================
df_s = pd.read_csv(solid_path, skipinitialspace=True)
df_s = clean_headers(df_s)
print("Solid columns:", df_s.columns.tolist())

xs = get_col(df_s, "x-coordinate", "x")
ys = get_col(df_s, "y-coordinate", "y")
Ts = get_col(df_s, "temperature", "static-temperature")

ys = np.where(np.abs(ys) < 1e-12, 0.0, ys)

xs_star = xs / H
ys_star = ys / H
theta_s = (Ts - Te) / q_flux_H_over_kf

# Smooth solid grid strictly inside obstacle rectangle
xi_s = np.linspace(Le_star, Le_star + w_star, 280)
yi_s = np.linspace(0.0, h_star, 280)
Xi_s, Yi_s = np.meshgrid(xi_s, yi_s)
Theta_s_grid = interp_to_grid(xs_star, ys_star, theta_s, Xi_s, Yi_s)

ts_min, ts_max = float(np.nanmin(Theta_s_grid)), float(np.nanmax(Theta_s_grid))
theta_levels_solid = np.linspace(ts_min, ts_max, 6)

# ============================================================
# PLOT 1: STREAMLINES (FIXED: includes 0.01 like paper)
# ============================================================
plt.rcParams.update({"font.size": 12, "axes.linewidth": 1.0})
fig, ax = plt.subplots(figsize=(10, 2.8))

# Main streamlines
CS1 = ax.contour(Xi, Yi, Psi_plot, levels=levels_main, colors="black", linewidths=0.8)
ax.clabel(CS1, inline=True, fontsize=9, fmt="%0.1f")

# Small levels (force 0.01 to be included if inside range)
levels_small = filter_levels(levels_small_candidates, psi_min, psi_max)

# Ensure 0.01 is present when possible
if (psi_min <= 0.010 <= psi_max) and (0.010 not in levels_small):
    levels_small.append(0.010)
    levels_small = sorted(levels_small)

if len(levels_small) > 0:
    CSs = ax.contour(Xi, Yi, Psi_plot, levels=levels_small, colors="black", linewidths=0.9)
    ax.clabel(CSs, inline=True, fontsize=8, fmt="%0.3f")
else:
    print("WARNING: No small streamline levels fall inside Psi range; 0.01 may not appear.")

# Obstacle: white with black border (paper style)
obstacle = plt.Rectangle((Le_star, 0), w_star, h_star,
                         facecolor="white", edgecolor="black",
                         linewidth=1.2, zorder=30)
ax.add_patch(obstacle)

ax.set_xlim(XMIN, XMAX)
ax.set_ylim(YMIN, YMAX)
ax.set_xlabel(r"$x^*$")
ax.set_ylabel(r"$y^*$")
ax.set_xticks([2, 3, 4, 5])
ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
ax.set_title(fr"Streamlines: $Re_{{D_h}}$ = {Re_label}, $w^*=h^*=0.25$, $k_s/k_f=10$")

plt.tight_layout()
plt.savefig(BASE / f"{SAVE_PREFIX}_streamlines.png", dpi=DPI)
plt.show()

# ============================================================
# PLOT 2: ISOTHERMS (UNCHANGED: keep your good version)
# ============================================================
fig, ax = plt.subplots(figsize=(10, 2.8))

theta_levels_f = filter_levels(theta_levels_requested, th_min, th_max)
if len(theta_levels_f) < 2:
    theta_levels_f = np.linspace(max(1e-4, th_min), th_max, 12).tolist()

CSf = ax.contour(Xi, Yi, Theta_plot, levels=theta_levels_f, colors="black", linewidths=0.8)
ax.clabel(CSf, inline=True, fontsize=8, fmt="%0.3f")

CSs2 = ax.contour(Xi_s, Yi_s, Theta_s_grid, levels=theta_levels_solid, colors="black", linewidths=0.9)
# keep solid labels OFF for cleaner look (paper uses leader-lines)
# ax.clabel(CSs2, inline=True, fontsize=8, fmt="%0.3f")

obstacle = plt.Rectangle((Le_star, 0), w_star, h_star,
                         facecolor="none", edgecolor="black",
                         linewidth=1.2, zorder=40)
ax.add_patch(obstacle)

ax.set_xlim(XMIN, XMAX)
ax.set_ylim(YMIN, YMAX)
ax.set_xlabel(r"$x^*$")
ax.set_ylabel(r"$y^*$")
ax.set_xticks([2, 3, 4, 5])
ax.set_yticks([0, 0.25, 0.5, 0.75, 1.0])
ax.set_title(fr"Isotherms: $Re_{{D_h}}$ = {Re_label}, $w^*=h^*=0.25$, $k_s/k_f=10$")

plt.tight_layout()
plt.savefig(BASE / f"{SAVE_PREFIX}_isotherms.png", dpi=DPI)
plt.show()

print("Saved:")
print(" ", BASE / f"{SAVE_PREFIX}_streamlines.png")
print(" ", BASE / f"{SAVE_PREFIX}_isotherms.png")